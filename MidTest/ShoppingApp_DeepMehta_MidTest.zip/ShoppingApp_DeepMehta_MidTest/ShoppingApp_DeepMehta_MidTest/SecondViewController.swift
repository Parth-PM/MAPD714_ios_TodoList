//
//  SecondViewController.swift
//  ShoppingApp_DeepMehta_MidTest
//
//  Created by Parth Maru on 2022-10-30.
//

import UIKit

class SecondViewController: UIViewController {

    var shoppingList: String?
    var item1: String?
    var item2: String?
    var item3: String?
    var item4: String?
    var item5: String?
    var item1Quantity: String?
    var item2Quantity: String?
    var item3Quantity: String?
    var item4Quantity: String?
    var item5Quantity: String?
    
    @IBOutlet weak var ListNameOutput: UILabel!
    
    @IBOutlet weak var Name1Output: UILabel!
    
    @IBOutlet weak var Name2Output: UILabel!
    
    @IBOutlet weak var Name3Output: UILabel!
    
    @IBOutlet weak var Name4Output: UILabel!
    
    @IBOutlet weak var Name5Output: UILabel!
    
    @IBOutlet weak var Label1Output: UILabel!
    
    @IBOutlet weak var Label2Output: UILabel!
    
    @IBOutlet weak var Label3Output: UILabel!
    
    @IBOutlet weak var Label4Output: UILabel!
    
    @IBOutlet weak var Label5Output: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        ListNameOutput.text = shoppingList
        Name1Output.text = item1
        Name2Output.text = item2
        Name3Output.text = item3
        Name4Output.text = item4
        Name5Output.text = item5
        
        Label1Output.text = item1Quantity
        Label2Output.text = item2Quantity
        Label3Output.text = item3Quantity
        Label4Output.text = item4Quantity
        Label5Output.text = item5Quantity
    }
    

}

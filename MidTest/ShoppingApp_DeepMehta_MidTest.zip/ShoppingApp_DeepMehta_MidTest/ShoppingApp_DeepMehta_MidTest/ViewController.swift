//
//  ViewController.swift
//  ShoppingApp_DeepMehta_MidTest
//
//  Created by Parth Maru on 2022-10-30.
//

import UIKit

class ViewController: UIViewController {

    // List Name Text Field
    @IBOutlet weak var ListNameText: UITextField!
    
    // 1-5 Item Name Text Field
    @IBOutlet weak var itemNameText1: UITextField!
    
    @IBOutlet weak var itemNameText2: UITextField!
    
    @IBOutlet weak var itemNameText3: UITextField!
    
    @IBOutlet weak var itemNameText4: UITextField!
    
    @IBOutlet weak var itemNameText5: UITextField!
    
    // 1-5 Item Name Quantity Field

    @IBOutlet weak var itemQuan1: UILabel!
    
    @IBOutlet weak var itemQuan2: UILabel!
    
    @IBOutlet weak var itemQuan3: UILabel!
    
    @IBOutlet weak var itemQuan4: UILabel!
    
    @IBOutlet weak var itemQuan5: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ListNameText.text = "Shopping List"
        
    }
    
    // Stepper Functions for Items 1-5

    @IBAction func stepper1(_ sender: UIStepper) {
        itemQuan1.text = String(Int(sender.value))
    }
    
    @IBAction func stepper2(_ sender: UIStepper) {
        itemQuan2.text = String(Int(sender.value))
    }
    
    @IBAction func stepper3(_ sender: UIStepper) {
        itemQuan3.text = String(Int(sender.value))
    }
    
    @IBAction func stepper4(_ sender: UIStepper) {
        itemQuan4.text = String(Int(sender.value))
    }
    
    @IBAction func stepper5(_ sender: UIStepper) {
        itemQuan5.text = String(Int(sender.value))
    }
 
    // Cancel Button Function to Reset everything

    @IBAction func cancelbtn(_ sender: UIButton) {
        ListNameText.text = "Shopping List"
        
        let emptystr = ""
        
        itemQuan1.text = String(0)
        itemQuan2.text = String(0)
        itemQuan3.text = String(0)
        itemQuan4.text = String(0)
        itemQuan5.text = String(0)
        
        itemNameText1.text = emptystr
        itemNameText2.text = emptystr
        itemNameText3.text = emptystr
        itemNameText4.text = emptystr
        itemNameText5.text = emptystr
    }
    
    // Saving the values in the next screen by using Segues
    
    
    @IBAction func Savebtn(_ sender: UIButton) {
        print(itemNameText1.text , itemQuan1.text)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Creating variables to store the name of shopping list and items entered in textFields

        
        let shoppingList = ListNameText.text
        
        let Text1 = itemNameText1.text
        let Text2 = itemNameText2.text
        let Text3 = itemNameText3.text
        let Text4 = itemNameText4.text
        let Text5 = itemNameText5.text
        
        let Quantity1 = itemQuan1.text
        let Quantity2 = itemQuan2.text
        let Quantity3 = itemQuan3.text
        let Quantity4 = itemQuan4.text
        let Quantity5 = itemQuan5.text
        
        // Create a new variable to store the instance of the SecondViewController

        let OutputData = segue.destination as! SecondViewController
        
        OutputData.shoppingList = shoppingList
        OutputData.item1 = Text1
        OutputData.item2 = Text2
        OutputData.item3 = Text3
        OutputData.item4 = Text4
        OutputData.item5 = Text5
        OutputData.item1Quantity = Quantity1
        OutputData.item2Quantity = Quantity2
        OutputData.item3Quantity = Quantity3
        OutputData.item4Quantity = Quantity4
        OutputData.item5Quantity = Quantity5
    }
}

